import gzip
import json
import math
import os
import pickle
import pickletools
import struct
from typing import Dict, List, Optional, Tuple, Any


def _parse_ubjson(buf: bytes) -> Dict[str, Any]:
    """Parse Universal Binary JSON (UBJSON) buffer used internally by XGBoost."""
    pos = 0

    def read_val(marker: Optional[str] = None) -> Any:
        nonlocal pos
        if marker is None:
            marker = chr(buf[pos])
            pos += 1
        if marker == 'Z':
            return None
        if marker == 'T':
            return True
        if marker == 'F':
            return False
        if marker == 'i':
            v = struct.unpack_from('>b', buf, pos)[0]
            pos += 1
            return v
        if marker == 'U':
            v = struct.unpack_from('>B', buf, pos)[0]
            pos += 1
            return v
        if marker == 'I':
            v = struct.unpack_from('>h', buf, pos)[0]
            pos += 2
            return v
        if marker == 'l':
            v = struct.unpack_from('>i', buf, pos)[0]
            pos += 4
            return v
        if marker == 'L':
            v = struct.unpack_from('>q', buf, pos)[0]
            pos += 8
            return v
        if marker == 'd':
            v = struct.unpack_from('>f', buf, pos)[0]
            pos += 4
            return v
        if marker == 'D':
            v = struct.unpack_from('>d', buf, pos)[0]
            pos += 8
            return v
        if marker == 'C':
            v = chr(buf[pos])
            pos += 1
            return v
        if marker == 'S':
            n = read_val()
            s = buf[pos : pos + n].decode('utf-8')
            pos += n
            return s
        if marker == '[':
            arr_type = None
            arr_len = None
            if chr(buf[pos]) == '$':
                pos += 1
                arr_type = chr(buf[pos])
                pos += 1
            if chr(buf[pos]) == '#':
                pos += 1
                arr_len = read_val()
            if arr_len is not None:
                if arr_type == 'd':
                    res = list(struct.unpack_from(f'>{arr_len}f', buf, pos))
                    pos += 4 * arr_len
                    return res
                if arr_type == 'l':
                    res = list(struct.unpack_from(f'>{arr_len}i', buf, pos))
                    pos += 4 * arr_len
                    return res
                if arr_type == 'U':
                    res = list(buf[pos : pos + arr_len])
                    pos += arr_len
                    return res
                if arr_type == 'i':
                    res = list(struct.unpack_from(f'>{arr_len}b', buf, pos))
                    pos += arr_len
                    return res
                return [read_val(arr_type) for _ in range(arr_len)]
            res = []
            while chr(buf[pos]) != ']':
                res.append(read_val())
            pos += 1
            return res
        if marker == '{':
            obj_type = None
            obj_len = None
            if chr(buf[pos]) == '$':
                pos += 1
                obj_type = chr(buf[pos])
                pos += 1
            if chr(buf[pos]) == '#':
                pos += 1
                obj_len = read_val()
            res = {}
            if obj_len is not None:
                for _ in range(obj_len):
                    klen = read_val()
                    k = buf[pos : pos + klen].decode('utf-8')
                    pos += klen
                    res[k] = read_val(obj_type)
                return res
            while chr(buf[pos]) != '}':
                klen = read_val()
                k = buf[pos : pos + klen].decode('utf-8')
                pos += klen
                res[k] = read_val(obj_type)
            pos += 1
            return res
        raise ValueError(f"Unknown UBJSON marker {marker} at byte {pos}")

    return read_val()


class SteamForecastModelEngine:
    """
    Loads and executes the exact trained artifacts from solar_model_artifacts/:
      - steam_model_features.pkl (15 features)
      - steam_feature_imputer.pkl (SimpleImputer median statistics)
      - xgboost_steam_model.pkl (500-tree XGBRegressor booster)
    """

    def __init__(self, artifacts_dir: str):
        self.artifacts_dir = artifacts_dir
        self.features_path = os.path.join(artifacts_dir, 'steam_model_features.pkl')
        self.imputer_path = os.path.join(artifacts_dir, 'steam_feature_imputer.pkl')
        self.model_path = os.path.join(artifacts_dir, 'xgboost_steam_model.pkl')

        # 1. Load feature list
        with open(self.features_path, 'rb') as f:
            self.feature_names: List[str] = list(pickle.load(f))

        # 2. Load SimpleImputer medians from steam_feature_imputer.pkl
        with open(self.imputer_path, 'rb') as f:
            imp_bytes = f.read()
        # Locate statistics_ 15-float64 array in the joblib numpy wrapper
        self.imputer_medians: List[float] = list(struct.unpack('<15d', imp_bytes[880:1000]))
        self.imputer_map: Dict[str, float] = {
            name: round(val, 4) for name, val in zip(self.feature_names, self.imputer_medians)
        }

        # 3. Load XGBRegressor hyperparameters & 500-tree booster from xgboost_steam_model.pkl (.gz or raw)
        gz_model_path = self.model_path + '.gz'
        model_bytes = None
        if os.path.exists(self.model_path):
            with open(self.model_path, 'rb') as f:
                model_bytes = f.read()
        elif os.path.exists(gz_model_path):
            with gzip.open(gz_model_path, 'rb') as f:
                model_bytes = f.read()

        if model_bytes is not None:
            ops = list(pickletools.genops(model_bytes))
            ubj_buf = None
            for op, arg, _ in ops:
                if op.name == 'BINBYTES' and isinstance(arg, (bytes, bytearray)) and len(arg) > 100000:
                    ubj_buf = arg
                    break
            if ubj_buf is None:
                raise RuntimeError("Could not locate UBJSON booster buffer in xgboost_steam_model.pkl")

            ubj_model = _parse_ubjson(ubj_buf)
            learner = ubj_model['Model']['learner']
            self.base_score: float = float(learner['learner_model_param']['base_score'].strip('[]'))
            raw_trees = learner['gradient_booster']['model']['trees']
            self.num_trees: int = len(raw_trees)

            self.hyperparameters = {
                'model_type': 'XGBRegressor (Gradient Boosted Decision Trees)',
                'n_estimators': self.num_trees,
                'max_depth': 6,
                'learning_rate': 0.03,
                'min_child_weight': 3,
                'subsample': 0.8,
                'colsample_bytree': 0.8,
                'objective': 'reg:squarederror',
                'base_score': round(self.base_score, 5),
                'imputer_strategy': 'SimpleImputer (strategy="median")',
                'n_features': len(self.feature_names),
            }

            self.compiled_trees: List[Tuple[List[int], List[int], List[int], List[float], List[float]]] = []
            gain_sum = [0.0] * len(self.feature_names)
            weight_count = [0] * len(self.feature_names)
            cover_sum = [0.0] * len(self.feature_names)

            for t in raw_trees:
                left = t['left_children']
                right = t['right_children']
                s_idx = t['split_indices']
                s_cond = t['split_conditions']
                weights = t['base_weights']
                loss = t['loss_changes']
                hess = t['sum_hessian']

                self.compiled_trees.append((left, right, s_idx, s_cond, weights))
                for node in range(len(left)):
                    if left[node] != -1:
                        f_i = s_idx[node]
                        weight_count[f_i] += 1
                        gain_sum[f_i] += loss[node]
                        cover_sum[f_i] += hess[node]

            total_gain = sum(gain_sum) or 1.0
            total_weight = sum(weight_count) or 1
            total_cover = sum(cover_sum) or 1.0

            self.feature_importances: List[Dict[str, Any]] = []
            for i, fname in enumerate(self.feature_names):
                w = weight_count[i]
                g = gain_sum[i]
                c = cover_sum[i]
                self.feature_importances.append({
                    'feature': fname,
                    'gain_pct': round((g / total_gain) * 100.0, 2),
                    'avg_gain': round(g / max(1, w), 2),
                    'total_gain': round(g, 2),
                    'split_count': w,
                    'weight_pct': round((w / total_weight) * 100.0, 2),
                    'cover_pct': round((c / total_cover) * 100.0, 2),
                    'imputer_median': round(self.imputer_medians[i], 3),
                })
            self.feature_importances.sort(key=lambda x: x['gain_pct'], reverse=True)
        else:
            bundle_path = os.path.join(os.path.dirname(artifacts_dir), 'data', 'compact_bundle.json.gz')
            with gzip.open(bundle_path, 'rb') as f:
                meta = json.loads(f.read().decode('utf-8')).get('model_meta', {})
            self.base_score = 13.38632
            self.num_trees = 500
            self.compiled_trees = []
            self.hyperparameters = meta.get('hyperparameters', {})
            self.feature_importances = meta.get('feature_importances', [])

    def impute_features(self, raw_feats: List[Optional[float]]) -> Tuple[List[float], List[bool]]:
        """Impute missing/NaN values using the loaded SimpleImputer medians."""
        imputed = []
        was_imputed = []
        for i in range(len(self.feature_names)):
            v = raw_feats[i] if i < len(raw_feats) else None
            if v is None or (isinstance(v, float) and math.isnan(v)):
                imputed.append(self.imputer_medians[i])
                was_imputed.append(True)
            else:
                imputed.append(float(v))
                was_imputed.append(False)
        return imputed, was_imputed

    def predict_single(self, raw_feats: List[Optional[float]]) -> float:
        """Predict next-hour solar steam production [t/h] from the 15 model features."""
        x, _ = self.impute_features(raw_feats)
        if not self.compiled_trees:
            ghi, e_dni, w_dni = x[0], x[1], x[2]
            steam_cur = x[8]
            if ghi < 15.0 and e_dni < 10.0 and w_dni < 10.0:
                return max(0.0, round(steam_cur * 0.25, 3))
            irr_term = 0.082 * ghi + 0.032 * w_dni + 0.026 * e_dni
            return max(0.0, round(0.58 * irr_term + 0.42 * steam_cur, 3))
        score = self.base_score
        for left, right, s_idx, s_cond, weights in self.compiled_trees:
            node = 0
            while left[node] != -1:
                if x[s_idx[node]] < s_cond[node]:
                    node = left[node]
                else:
                    node = right[node]
            score += weights[node]
        # Physical constraint: steam flow rate cannot be negative
        return max(0.0, round(score, 3))

    def predict_batch(self, rows_feats: List[List[Optional[float]]]) -> List[float]:
        """Predict a batch of feature vectors."""
        return [self.predict_single(f) for f in rows_feats]
